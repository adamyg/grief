/* lib/config.h. */

#define TRE_REGEX_T_FIELD value
